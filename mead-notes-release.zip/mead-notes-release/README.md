# mead-notes
A place to keep notes that can be managed with automation
